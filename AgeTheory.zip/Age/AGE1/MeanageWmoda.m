dt=0.1;         %[day/intervals]
alfa=5;         %[mm]
lambda=0.4;     %[1/day]
eta=0.05;       %[1/day]
starting=1;
finish=100000;
i=1;
input=zeros(1,finish/dt);
for t=starting:dt:finish
    p=rand;
    if p<lambda*dt
        input(i)=expinv(rand,alfa);
    else
        input(i)=0;
    end
    i=i+1;
end
W(1)=alfa*lambda/eta;
i=2;
for t=starting:dt:(finish)
    W(i)=W(i-1)+input(i-1)-eta*W(i-1)*dt;
    i=i+1;
end
M(1)=W(1)/eta;
i=2;
for t=(starting):dt:(finish)
    M(i)=M(i-1)+W(i-1)*dt-eta*M(i-1)*dt;
    i=i+1;
end
A=M./W;
B=zeros(1,finish);
B(1)=log(1/eta);
i=2;
for t=(starting+dt):dt:finish
    B(i)=B(i-1)+exp(-B(i-1))*dt-input(i)*eta/((lambda-eta)*alfa);
    i=i+1;
end
Am=exp(B);
syms x
Pdfm(x)=lambda^(lambda/eta)/gamma(lambda/eta)*x^(lambda/eta-1)*exp(-lambda*x);
nbins=calcnbins(Am);
nbins1=calcnbins(A);
hold on
histnorm(A,nbins1,1);
histnorm(Am,nbins,1);
ezplot(Pdfm(x),[0,100])
hold off


