dt=0.1;         %[day/intervals]
por=0.5;         %porosita'
Zr=150;            %[mm]soil depth
Alfa=5;         %[mm]
alfa=Alfa/por/Zr;
lambda=0.4;     %[1/day]
ET=7;
eta=0.1;       %[1/day]
starting=1;
finish=100000;
i=1;
input=zeros(1,finish/dt);
for t=starting:dt:finish
    p=rand;
    if p<lambda*dt
        input(i)=expinv(rand,alfa);
    else
        input(i)=0;
    end
    i=i+1;
end
W(1)=0;
i=2;
for t=starting:dt:(finish)
    W(i)=W(i-1)+input(i-1)-eta*W(i-1)*dt;
    i=i+1;
end
M(1)=W(1)/eta;
i=2;
for t=(starting):dt:(finish)
    M(i)=M(i-1)+W(i-1)*dt-eta*M(i-1)*dt;
    i=i+1;
end
A=M./W;
B=zeros(1,finish/dt);
B(1)=log(1);
i=2;
for t=(starting+dt):dt:finish
    B(i)=B(i-1)+exp(-B(i-1))*dt-input(i)*eta/(lambda*alfa);
    i=i+1;
end
Am=exp(B);
syms x
Pdf(x)=lambda^(lambda/eta+1)/gamma(lambda/eta+1)*x^(lambda/eta)*exp(-lambda*x);
nbins=calcnbins(Am);
nbins1=calcnbins(A);
hold on
histnorm(A,nbins1,1);
histnorm(Am,nbins,1);
ezplot(Pdf(x),[0,40])
hold off

histM=histnorm(M,calcnbins(M),1);   %istogramma per M

gamm=1/alfa;      %plotto la pdf della variabile W-----alla fine importata da mathematica  
pdfG(x)=gamm^(lambda/eta)/gamma(lambda/eta)*exp(-gamm*x)*x^(lambda/eta-1);
ezplot(pdfG(x),[0,100])

hold on
histnorm(A,nbins1,1);
histnorm(Am,nbins,1);
ezplot(Pdf(x),[0,1000])
hold off
figure
plot(W)
plot(M)
hold on
plot(Am)
plot(A)
hold off
ezplot(pdfGamma(x),[0,100])
plot(X,pdfG)
histM=histnorm(M,calcnbins(M),1);
hold on
histnorm(A,nbins1,1);
histnorm(Am,nbins,1);
ezplot(Pdf(x),[0,100])
hold off



