dt=0.1;         %[day/intervals]
Alfa=5;         %[mm]
lambda=0.4;     %[1/day]
eta=7;       %[1/day]
LENGTH=10000;
starting=0;
finish=60;
beta=zeros(1,LENGTH);
it=1000;
por=0.5;
Zr=150;
t=60;
tau=15;
k=0.1;
alfa=Alfa/por/Zr;
for x=1:it
    i=1;
  for tt=starting:dt:finish
    p=rand;
    if p<lambda*dt
        input(x,i)=expinv(rand,alfa*exp(-k*tau));
    else
        input(x,i)=0;
    end
    i=i+1;
  end
     x
end
v=zeros(it,length(input(1,:)));
for j=1:it
    v(j,1)=input(j,1);
    for r=2:length(input(j,:))
    v(j,r)=v(j,r-1)+input(j,r);
    end
end

X=0:0.1:60;
ensembleP=zeros(1,length(input(1,1:601)));

for p=1:length(input(1,1:601))
    ensembleP(p)=mean(v(:,p));
end

hold on
for k=1:50
    plot(X,v(k,:),'color',[0.5 0.5 0.5])
end
plot(X,ensembleP(1:601),'linewidth',2)
hold off

