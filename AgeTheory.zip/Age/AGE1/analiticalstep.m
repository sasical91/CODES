LENGTH=20000;
t=1:LENGTH;
ANNI=LENGTH/365;
n=zeros(LENGTH,300);
beta=50;
alfa = importdata('RainStati.txt');
lambda(1:LENGTH)=0.05; 
for i=301:LENGTH
        for a=1:300
        lambda1=sum(lambda(i-a+1098+2:i+1098));
        lambda2=sum(lambda(1:i));
            if a<i
            n(i,a)=alfa(i-a)*exp(-lambda1);
            else
             n(i,a)=beta*exp(-lambda2);
            end
        end
end
for j=1:20000
    W(j)=sum(n(j,:));
end
for k=301:18000
    for kk=1:300
       M(kk)=kk*n(k,kk);
    end
    m(k)=sum(M(:));
end
am=m(301:18000)./W(301:18000);