%dichiarazioni
RainStati = importdata('RainStati.txt');
sh=0.19;                %I use a loamy soil
sw=0.24;
ss=0.57;
sfc=0.65;
n=0.45;
Zr=500;
Zc=0.9;  %soil depth available for carbon stock
Ksat=200;
Emax=14000;
Tmin=-4;      %temperature at which biological activity stops
Tmax=25;      %max temperature reached from soil
ET2=3;        %above this ET, productivity is not limited by T
ET1=2.5;         %under this ET, productivity is limited
LENGTH=length(RainStati); % Lunghezza della simulazione 
Tw=182;       %Length of we season
Td=365-Tw;    %Length of dry/growing season
Bmax=4.4;     %maximum rate of biomass growth according to litter measurements on the "TEDESCHI2006"
Kcmax=5*10^-4;    %maximum rate of respiration according to Paper sulle misurazioni "TEDESCHI2006"(trovato tale che il carbonio stoccato sia intorno a 5e+3
alfamin=3;         %minimum rainfall depth
alfamax=7;          %maximum rainfall rate
lambdamax=0.8;       %maximum and minimum rainfall frequency
lambdamin=0.1;
Ew=0.1;                         %Evaporation from soil
ET_max= 6;                      % Massimo valore di evapotraspirazione giornaliera durante l'anno [mm/day]
ET_min= 2;                      % Minimo valore di evapotraspirazione giornaliera durante l'anno [mm/day]
                %%%%%%%%%%%%%%%%SIMULATION%%%%%%%%%%%%%%%%%

for i=1:LENGTH+365
t(i)=mod(i,365);               %I generate a temporal axis (1-365) in order to express the fucntions depending on the day of the year
end
t=t+1;
t=t(365:LENGTH+365);
R=RainStati/n/Zr*10;     %porto in mm
%FACCIO IL BILANCIO
s(1)=sfc;                       
for j=2:LENGTH                                           
    ETmax(j)=10;
    ET(j)=ETmax(j)/n/Zr*s(j-1);
    s(j)=s(j-1)+R(j)-ET(j);                              %equazione di bilancio
 end
 S=s*n*Zr;                                       
years=floor(LENGTH/365);                             %in base alla lunghezza del vettore rain, calcolo il numero di anni compresi
fatmolt=10;       
NC(1)=round(S(1));                                   %rieseguo il bilancio ma costruendo di volta in volta un vettore contenente le et� delle particelle
e(1)=Emax/2; 
N=round(Emax*rand(NC(1),1));
for vv=1:max(N)                                      %calcolo m(t)--guarda Amilcare's note for notation
M(1,vv)=vv*sum(N==vv);
end
m(1)=sum(M(1,:));
a(1)=m(1)/NC(1);                                     %calcolo mean age
for v=2:2000
N=N+1;
I(v)=round(R(v)*n*Zr);
O(v)=round((ET(v)*n*Zr));
NC(v)=NC(v-1)+I(v);
N(NC(v-1)+1:NC(v))=1;
if O(v)<1
    N=N;
else
      Ou=O(v);  
  OO=rand(Ou,1);
  re=round(1+(length(N)-1)*OO); 
  N(re)=[];
 end
NC(v)=NC(v)-O(v);
e(v)=mean(N);                 %Keep in memory the number of carbon particles and mean and variance of age distribution
Var(v)=var(N);
for vv=1:max(N)
M(v,vv)=vv*sum(N==vv);
end
m(v)=sum(M(v,:));
a(v)=m(v)/NC(v);
end

   save('w(t).txt','S','-ASCII') 