dt=0.1;         %[day/intervals]
Alfa=5;         %[mm]
lambda=0.4;     %[1/day]
eta=7;       %[1/day]
LENGTH=10000;
starting=1;
finish=10000;
beta=zeros(1,LENGTH);
por=0.5;
Zr=150;
i=1;
input=zeros(1,finish/dt);
for t=starting:dt:finish
    p=rand;
    if p<lambda*dt
        input(i)=expinv(rand,Alfa);
    else
        input(i)=0;
    end
    i=i+1;
end
alfa=input/por/Zr;
K=0.0933;      %pongo K=0.1
t=1;
for i=0:0.1:LENGTH
    a=1;
        for j=0:0.1:300
           % lambda1=sum(ET(i-j+1095+2:i+1095));
            %lambda2=sum(ET(2:i));
            if j<i
             n(t,a)=alfa(t-a+1)*exp(-K*j);
            else
             n(t,a)=beta(a-t+1)*exp(-K*i);
            end
            a=a+1;
        end
        t=t+1;
end
X=[1:1:1000];
Y=[1:1:3001];
hold on
plot3(repmat(250,size(Y)),Y,n(250,:))
plot3(repmat(499,size(Y)),Y,n(499,:))
plot3(repmat(750,size(Y)),Y,n(750,:))
plot3(repmat(1000,size(Y)),Y,n(1000,:))

plot3(X,repmat(1,size(X)),alfa(1:1000))

C0=[1:1:3001];
plot(C0(1:1000),Y(1:1000));
plot(C0(401:900),Y(1:500));


for t=1:1000        %calcolo la media
Integ(t)=sum(n(t,:));
for tt=1:length(n(100,:))
tn(tt)=tt*n(t,tt);
end
Media(t)=sum(tn(:))/Integ(t);
end
plot(X,Media)

%creo l'ensemble della distribution
N=Alfa*lambda/por/Zr*exp((-K).*Y*dt);
plot3(repmat(750,size(Y)),Y,N)


