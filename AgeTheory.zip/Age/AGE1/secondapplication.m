figure
c=2;
syms a
theta(a) = (a/(c+1))^(c);
phi(a)=exp(-(a/(1+c))^(1+c));
delta(a)=(a/(c+1))^(c)*exp(-(a/(1+c))^(1+c));
hold on
ezplot(theta(a), [0, 30])
ezplot(phi(a), [0, 30])
ezplot(delta(a), [0, 30])
hold off