LENGTH=100000;
 t=1:LENGTH;
ANNI=LENGTH/366;
n=zeros(LENGTH,300);
n(1,:)=50;
lambda (1:LENGTH)=0.05;
alfa = importdata('RainStati.txt');
for i=1:LENGTH
    semester=floor((i-1)/183)*183;
    for a=1:300
        lambda1=sum(lambda(i-a+1098+2:i+1098));
        lambda2=sum(lambda(2+semester:i));
        if semester<1
            if a<i-semester
            n(i,a)=alfa(i-a+1098+1)*exp(-lambda1);
            else
               if semester<1
               n(i,a)=n(semester+1,a)*exp(-lambda2);
               else
               n(i,a)=n(semester,a)*exp(-lambda2);
               end
            end
        else
            if a<i-semester+1
            n(i,a)=alfa(i-a+1098+1)*exp(-lambda1);
            else
               if semester<1
               n(i,a)=n(semester+1,a)*exp(-lambda2);
               else
               n(i,a)=n(semester,a)*exp(-lambda2);
               end
            end
        end
    end
end