LENGTH=10000;
Zr=150;
por=0.5;
t=1:LENGTH;
ANNI=LENGTH/365;
D=8;   %parameters distributions
n=zeros(LENGTH,300);
beta=zeros(1,LENGTH);
beta(1:200)=0;
alfa(1:LENGTH)=2; %mm
alfa(500:LENGTH)=2;   %mm
alfa=alfa;
ET=7;   %mm/day
c=2;
K=ET/por/Zr;   %ET/n/Zr
age=[1:1:300];
t=1;
for i=0:0.1:LENGTH
    a=1;
        for j=0:0.1:300
           % lambda1=sum(ET(i-j+1095+2:i+1095));
            %lambda2=sum(ET(2:i));
            if j<i
             n(t,a)=alfa(t-a+1)*exp(-(j/(1+c))^(1+c));
            else
             n(t,a)=beta(a-t+1)*exp(-K*i);
            end
            a=a+1;
        end
        t=t+1;
end
X=[1:1:1000];
Y=[1:1:3001];
hold on
plot3(repmat(10,size(Y)),Y,n(10,:))
plot3(repmat(50,size(Y)),Y,n(50,:))
plot3(repmat(75,size(Y)),Y,n(75,:))
hold off

for u=1:1000   %calcolo w come integrale di n
W(u)=sum(n(u,:))*0.1;
end

w(1)=0;
i=2;
for t=dt:dt:100      %calcolo numericamente
    w(i)=w(i-1)+2*alfa(i-1)*exp(-(t/(1+c))^(1+c))*dt;
    i=i+1;
end


for t=1:1000        %calcolo la media
 Integ(t)=sum(n(t,:))*dt;
 for tt=1:length(n(t,:))
     tn(tt)=tt*dt*n(t,tt)*dt;
 end
 Media(t)=sum(tn(:))/Integ(t);
end

for t=1:1000         %calcolo theta
    for tt=1:length(n(t,:))
        the(tt)=tt*dt*n(t,tt)*(tt*dt/(1+c))^c*dt;
    end
    theta(t)=sum(the(:));
end

for t=1:1000         %calcolo m
    for tt=1:length(n(t,:))
        mm(tt)=tt*dt*n(t,tt)*dt;
    end
    m(t)=sum(mm(:));
end

for t=1:1000         %calcolo o
    for tt=1:length(n(t,:))
        oo(tt)=n(t,tt)*(tt*dt/(1+c))^c*dt;
    end
    o(t)=sum(oo(:));
end
thsum=theta./m;
isuw=alfa(1:length(W))./W;
osuw=o./W;
figure
hold on
plot(thsum)
plot(isuw)
plot(osuw)
hold off




